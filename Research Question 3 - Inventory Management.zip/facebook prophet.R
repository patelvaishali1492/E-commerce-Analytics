rm(list=ls()); gc()

library(prophet)  
library(dplyr)
library(caret)

df = read.csv('ts.csv')  #%>%  #read the data and log transform 
  
  #mutate(y = log(y))

set.seed(12)
ind.train = sample(1:nrow(df), nrow(df)*0.8)
ind.test = setdiff(1:nrow(df), ind.train)

train= df[ind.train,]
test = df[ind.test,]

#m = prophet()
m <- prophet(weekly.seasonality = T, yearly.seasonality = T, daily.seasonality = F)
#m <- add_seasonality(m, name='weekly', period=6, fourier.order=5)
#m <- add_regressor(m, 'Quantity', prior.scale = NULL, standardize = "auto")
#m <- add_regressor(m, 'error', prior.scale = NULL, standardize = "auto")
#m <- add_regressor(m, 'Revenue', prior.scale = NULL, standardize = "auto")
#m <- add_regressor(m, 'Activities', prior.scale = NULL, standardize = "auto")
m <- fit.prophet(m, df)

future <- make_future_dataframe(m, periods = 12) #predict 21 days


forecast <- predict(m, future)

#tail(forecast[c('ds', 'yhat', 'yhat_lower', 'yhat_upper')])


plot(m, forecast, xlab= "time")

prophet_plot_components(m, forecast)


#predict, obs
postResample(forecast[,'yhat'], df[,'y'])


df$error = df[,'y'] - forecast[,"yhat"]

df$predict = forecast[,"yhat"]

write.csv(df, file= 'error.csv')



#add in errors as regress

rm(list=ls()); gc()

dfn = read.csv('new.csv')

set.seed(12)
ind.train = sample(1:nrow(dfn), nrow(dfn)*0.8)
ind.test = setdiff(1:nrow(dfn), ind.train)

train= dfn[ind.train,]
test = dfn[ind.test,]

n <- prophet(weekly.seasonality = F, yearly.seasonality = T, daily.seasonality = F)
n <- add_seasonality(n, name='weekly', period=6, fourier.order=5)
#n <- add_regressor(n, 'Quantity', prior.scale = NULL, standardize = "auto")
n <- add_regressor(n, 'error', prior.scale = NULL, standardize = "auto")
#n <- add_regressor(m, 'T3', prior.scale = NULL, standardize = "auto")
n <- fit.prophet(n, dfn)

future <- make_future_dataframe(n, periods = 9)

fc = predict(n, dfn)


#tail(forecast[c('ds', 'yhat', 'yhat_lower', 'yhat_upper')])

plot(n, fc)

prophet_plot_components(n, fc)

summary(fc)

#postResample(pred, obs)
postResample(fc[,'yhat'], dfn[,'y'])

