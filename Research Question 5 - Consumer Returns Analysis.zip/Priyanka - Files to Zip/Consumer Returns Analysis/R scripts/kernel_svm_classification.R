# Kernel SVM functions
# 1. Gaussian - radial 2. sigmoid 3. Polynomial

# Import the dataset
data = read.csv('Classification.csv')

# Splitting the data
library(caTools)
set.seed(123)
split = sample.split(data$Returned, SplitRatio = 0.75)
training_set = subset(data, split == T)
test_set = subset(data, split == F)

# wecan also use kernlab library

# Fitting the kernel svm model in the training dataset
library(e1071)
classifier = svm(formula = Returned ~ .,
                 data = training_set,
                 type = 'C-classification',
                 kernel = 'radial')
classifier

# Predicting the test set
y_predict = predict(classifier, newdata = test_set[-42])
y_predict


#  confusion matrix
cm = table(test_set[, 42], y_predict)
cm


#visualizing the training set
library(ElemStatLearn)
set = training_set
x1 = seq(min(set[, 1]) -1, max(set[, 1]) + 1, by = 0.01)
x2 = seq(min(set[, 2]) -1, max(set[, 2]) + 1, by = 0.01)

grid_set = expand.grid(x1, x2)
colnames(grid_set) = c('Age', 'EstimatedSalary')
y_grid = predict(classifier, newdata = grid_set)
plot(set[, -3],
     main =  'Kernel SVM(Training set)',
     xlab = 'Age', ylab = 'Estimated Salary',
     xlim = range(x1), ylim = range(x2))
contour(x1, x2, matrix(as.numeric(y_grid), length(x1), length(x2)), add = TRUE)
points(grid_set, pch = '.',  col = ifelse(y_grid == 1, 'springgreen3', 'tomato'))
points(set, pch = 21, bg = ifelse(set[, 3] == 1, 'green3', 'red3'))

# Visualizing the test set
library(ElemStatLearn)
set = test_set
x1 = seq(min(set[, 1]) -1, max(set[, 1]) + 1, by = 0.01)
x2 = seq(min(set[, 2]) -1, max(set[, 2]) + 1, by = 0.01)

grid_set = expand.grid(x1, x2)
colnames(grid_set) = c('Age', 'EstimatedSalary')
y_grid = predict(classifier, newdata = grid_set)
plot(set[, -3],
     main =  'Kernel SVM(Test set)',
     xlab = 'Age', ylab = 'Estimated Salary',
     xlim = range(x1), ylim = range(x2))
contour(x1, x2, matrix(as.numeric(y_grid), length(x1), length(x2)), add = TRUE)
points(grid_set, pch = '.',  col = ifelse(y_grid == 1, 'springgreen3', 'tomato'))
points(set, pch = 21, bg = ifelse(set[, 3] == 1, 'green3', 'red3'))

