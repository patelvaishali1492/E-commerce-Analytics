rm(list=ls())

library(forecast)
library(caret)

dat = read.csv('ts.csv', head =T)

df <- ts(dat$y, frequency=6)

plot.ts(df, xlab= 'time', ylab = 'activities')

df


ht <- HoltWinters(df, seasonal = "multiplicative")

ht


fch = predict(ht, n.ahead = 12, prediction.interval = T)

fch

plot.ts(df, xlab= 'time', ylab = 'activities', xlim = c(38,45))
lines(ht$fitted[,1], col ="blue")
lines(fch[,1], col = 'green')
lines(fch[,2], col = 'red')
lines(fch[,3], col = 'red')

#postResample(predict, obs)
postResample(ht$fitted, dat[,"y"])

summary(ht)



write.csv(fch, file= 'holtpredict.csv')


#ETS
rm(list=ls())

library(forecast)

dat = read.csv('ts.csv', head =T)

df <- ts(dat$y, frequency=6)


fit <- ets(df)

fit

fc <- predict(fit, n.ahead = 12, prediction.interval = TRUE)

fc

plot(fc, xlim = c(37,45))
lines(fc$fitted, col = 'green')

postResample(fc$fitted, dat[,"y"])

fit
         
