#auto arima 

rm(list=ls())

library(forecast)

df = read.csv('ts.csv') 

dat1= ts(df$y, frequency = 6)


mo= auto.arima(dat1)

summary(mo)


fc= forecast(mo, h=12)
plot(fc, ylab = "activites", xlab = 'time', xlim= c(38,45))
lines(fc$fitted, col= "green")

fc


#arima

rm(list=ls())

library(forecast)

df = read.csv('ts.csv') 

dat1= ts(df$y, frequency = 6)

plot(df$y)
lines(df$y)

par(mfrow = c(2,1))
acf(df$y)
pacf(df$y)

di = diff(df$y)
ndi = length(di)

dat2= ts(di, frequency = 6)


plot(di)
lines(di)

par(mfrow = c(2,1))
acf(di)
pacf(di)

#d = 1

mo = arima(dat2, order = c(1,0,2))

mo

fc= forecast(mo, h=12)
plot(fc, ylab = "activites", xlab = 'time', xlim= c(38,45))
lines(fc$fitted, col= "green")

fc
