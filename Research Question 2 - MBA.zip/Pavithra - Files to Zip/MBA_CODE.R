rm(list=ls()); gc()

setwd('/Users/Pavithra/Desktop/577 Project')


a1 = read.csv('Final_Categories.csv',head=T,stringsAsFactors=F) 

head(a1)



## To install plyr, fist unninstall dplyr, and then try installing plyr##

if(sessionInfo()['basePkgs']=="dplyr" | sessionInfo()['otherPkgs']=="dplyr"){
  detach(package:dplyr, unload=TRUE)
}



library("plyr")
require("arulesViz")


install.packages("plyr")

install.package("dplyr")
require("dplyr")  
require("plyr") 


str(a1)


?date

?ddply
## convet character date into date format    CustomerID
a1$Date <- as.Date(a1$InvoiceDate, format = "%m/%d/%Y")


a1$InvoiceNo <- as.numeric(as.character(a1$InvoiceNo))



a1$Description <- as.factor(a1$Description)

## convert the dataframe into transactional format##

df_item <- ddply(a1,c("CustomerID","Date"), 
                 function(df1)paste(df1$Description, 
                                    collapse = ","))
##Check the final output##
head(df_item)
str(df_item)
write.csv(df_item,"TEST_1.csv")

## Delete the INvoice NO and Date column ##
df_item$CustomerID <- NULL
df_item$Date <- NULL

#Rename column headers for easy identification ##
colnames(df_item) <- c("Items")

##Check the final output##
head(df_item)

write.csv(df_item,"market_basket_new.csv", quote = FALSE, row.names = TRUE)

head()

## Inspect transactions

tr <- read.transactions('market_basket_new.csv', format = 'basket', sep=',')

summary(tr)

# Generate assocaition rules

rules1 <- apriori(tr, parameter = list(supp=0.01, conf=0.8, maxlen=12))
  
  ##10793
rules1 <- sort(rules1, by='confidence', decreasing = TRUE)
summary(rules1)



write(rules1, file = "FinalFullrules.csv", sep = ",", quote = TRUE, row.names = FALSE)

inspect(sort(rules1, by = "lift")[1:10])

inspect(rules1[10000:10020])


inspect(head(sort(rules, by ="lift"),3))


dim(df_item)

require(arulesViz)
require(arules)

topRules <- rules[1:10]

plot(topRules, method="graph")



#  REmoving repeating rules
redundant <- which (colSums (is.subset (rules1, rules1)) > 1) # get redundant rules in vector
length(redundant)

inspect(redundant[1:10])
rules_new <- rules1[-redundant] # remove redundant rules
length(rules_new)

write(rules_new, file = "rules_new.csv", sep = ",", quote = TRUE, row.names = FALSE)

inspect(rules_new[1:20])

summary(rules_new) ##3420 rules

## inspect the below rules

inspect(sort(rules_new, by = "lift")[20:60])  

## scatter plot

plot(rules_new, measure = c("support", "lift"), shading = "confidence")

## interactive scatter plot

sel <- plot(rules_new, measure = c("support", "lift"), shading = "confidence",  interactive = TRUE)

subrules2 <- head(rules_new, n = 10, by = "lift")


plot(subrules2, method = "graph")

topRules <- rules_new[1:10]
top_ten <- sort(rules_new, by = "lift")[1:10]
plot(top_ten)
inspect (topRules)

plot(top_ten, method = "graph") ## Tree Graph method

plot(top_ten,method="graph",interactive=TRUE,shading=NA)

## Choose specific rules
rules_a<-apriori(data=tr, parameter=list(supp=0.01,conf = 0.8,maxlen=12), 
               appearance = list(default="rhs",lhs="T-LIGHTS"),
               control = list(verbose=F))
inspect (rules_a)






