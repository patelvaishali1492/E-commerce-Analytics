rm(list=ls())

dat = read.csv('tlight.csv', head=T, stringsAsFactors=F, na.strings='')

#dat2 = aggregate(cbind(y)~ds,dat,length)

dat3 = aggregate(cbind(y)~ds,dat,sum)

#dat4 = merge(dat3,dat2, by = "InvoiceDate")
write.csv(dat3,"nlikght.csv")

# dat = read.csv('p4.csv', head=T, stringsAsFactors=F, na.strings='') #if we start out with just p4.csv

# install.packages("forecast") #install forcast 
library(forecast)

plot(dat$T,dat$Revenue, xlab= "T", ylab = "Revenue", type = "l") #plot graph X= T, Y= Revenue

id.rev = which(colnames(dat) %in% c('T', 'Revenue')) 

id.act = which(colnames(dat) %in% c('T', 'Act')) 

id.quan = which(colnames(dat) %in% c('T', 'Quantity')) 

Revenue = dat[,id.rev]

Quantity = dat[id.quan]

Activites = dat[id.act]