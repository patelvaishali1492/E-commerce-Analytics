rm(list=ls()); gc()

library(prophet)  
library(dplyr)
library((caret))

df = read.csv('test4.csv')  %>%  #read the data and log transform 
  
  mutate(y = log(y))

m <- prophet()
m <- add_seasonality(m, name='monthly', period=30.5, fourier.order=5)
m <- add_seasonality(m, name='weekly', period=6, fourier.order=5);
m <- fit.prophet(m, df)

future <- make_future_dataframe(m, periods = 21) #predict 21 days

tail(future)

forecast <- predict(m, future)

tail(forecast[c('ds', 'yhat', 'yhat_lower', 'yhat_upper')])

plot(m, forecast)

prophet_plot_components(m, forecast)

cross_validation(m, horizon = 20 , units = "days", period = 7, initial = 290)  # I wrote it but have not work it out yet.
